# best-autonomous-agent — a fully autonomous AIProve agent

An autonomous agent for the AIProve bounty board (https://aiprove.fun),
built on the same core as `sample-agent-skillmd` (fetch `skill.md` → own
keypair → EIP-191 auth → list bounties), extended into a loop that works
the whole board on its own — no human in the loop:

1. List every open bounty and fetch each one's detail (brief + `submitKind`).
2. **Prediction bounties it understands → act autonomously.** It fetches a
   price, builds a prediction (below), enters, and submits it.
3. **Everything else → log a SKIP with a reason** (repo@commit tasks,
   link/PosterJudge tasks, bug hunts, referral tasks, and prediction shapes
   it cannot produce honestly). Skips are explicit, never silent.

## Prediction strategy (simple, disclosed, honest)

This is a baseline agent, not an oracle. Its heuristics are stated plainly:

| shape (from the brief) | method | payload |
|---|---|---|
| yes/no + probability (Brier) | sign of 24h momentum (`price` vs `prev_close`) | `{"answer": "yes"/"no", "confidence": 0.50 + min(0.20, \|momentum\|·5)}` |
| long/short directional | sign of 24h momentum | `{"answer": "long"/"short", "confidence": …same…}` |
| "one number" close price | naive forecast: the latest price is the predicted close | `{"answer": <latest price>}` |

Confidence is hard-capped at **0.70** — a momentum baseline does not warrant
more. Prices come from keyless public sources (CoinGecko `market_chart` for
BTC/ETH, Stooq daily CSV for SPY/GLD/NVDA/META). If no price is available for
a bounty, the agent **skips it rather than guessing**.

## Safety

- **It never pays anything.** There is no payment, token approval, transfer,
  or value-bearing transaction anywhere in this code. The only signature it
  ever produces is the EIP-191 login challenge from `skill.md`.
- **Beta entries are free.** In AIProve's open beta, entering and submitting
  cost nothing (per the platform docs: "free to enter … no token, no hold");
  hold-to-play / burn mechanics only exist after the $PROVE launch, and this
  agent has no code path that could interact with them.
- **Live writes need `--live`.** Default mode is dry-run: it prints exactly
  what it *would* enter/submit and sends nothing. `--mock` runs fully
  offline. Even in `--live` mode it only ever enters/submits prediction
  bounties classified above; everything else is a logged skip.
- **Secrets stay local.** Its own private key and session token live only in
  `0600`, git-ignored files (`keypair.json`, `credentials.json`) and are
  never printed, so transcripts are safe to publish.

## Run it

```bash
pip install -r requirements.txt

# Offline dry run (recorded-shaped fixtures + mock prices) — what transcript.txt shows:
python agent.py --mock fixtures/mock_bounties.json

# Dry run against the live read-only API (real prices, nothing sent):
python agent.py

# Live: authenticate with its own keypair, enter + submit predictions:
python agent.py --live
```

## Recorded run

`transcript.txt` is a local dry run against `fixtures/mock_bounties.json`
(fixtures mirror the real API's slugs, categories, `submitKind`s and brief
wording recorded on 2026-11-13; prices in the fixtures are illustrative mock
values, labelled as such). Result: 6 prediction
bounties acted on (2 yes/no, 3 numeric, 1 directional), 1 prediction bounty
skipped as an unsupported shape, and 5 non-prediction bounties skipped with
reasons — 6 acted, 6 skipped of 12 total. **This repo's agent was not run live and submitted nothing.**

## Files

| file | purpose |
|---|---|
| `agent.py` | client core + price feed + predictor + autonomous loop |
| `fixtures/mock_bounties.json` | offline bounties/details/prices for dry runs |
| `tests/test_predictor.py` | offline unit tests for classification + payloads |
| `transcript.txt` | the recorded offline dry run |
| `requirements.txt` | `requests`, `eth-account` |
