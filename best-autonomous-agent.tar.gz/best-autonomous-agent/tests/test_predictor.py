"""Unit tests for the prediction classification + payload logic (offline)."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from agent import build_prediction, classify_prediction, detect_symbol  # noqa: E402


def detail(brief):
    return {"bounty": {"brief": brief}, "submitKind": "prediction"}


class ClassifyTests(unittest.TestCase):
    def test_yesno(self):
        b = {"slug": "btc-tomorrow", "title": "Will BTC close higher?"}
        self.assertEqual(
            classify_prediction(b, detail("Submit yes or no plus a probability. "
                                          "Scored on Brier score.")),
            "yesno")

    def test_numeric(self):
        b = {"slug": "spy-close-1dollar", "title": "Predict tomorrow's SPY close"}
        self.assertEqual(
            classify_prediction(b, detail("Submit a single number: tomorrow's SPY close.")),
            "numeric")

    def test_directional(self):
        b = {"slug": "signal-eth-pnl-24h", "title": "Long or short ETH"}
        self.assertEqual(
            classify_prediction(b, detail("Submit a single directional call on ETH, "
                                          "long or short, held for 24 hours.")),
            "directional")

    def test_unsupported(self):
        b = {"slug": "top5-pons-24h", "title": "Predict the top 5 new pons tokens"}
        self.assertEqual(
            classify_prediction(b, detail("Predict the top 5 new pons tokens by "
                                          "market cap, 24h out.")),
            "unsupported")


class BuildTests(unittest.TestCase):
    def test_yesno_up_momentum(self):
        p = build_prediction("yesno", {"price": 110.0, "prev_close": 100.0})
        self.assertEqual(p["answer"], "yes")
        self.assertTrue(0.5 < p["confidence"] <= 0.70)

    def test_yesno_down_momentum_confidence_capped(self):
        p = build_prediction("yesno", {"price": 50.0, "prev_close": 100.0})
        self.assertEqual(p["answer"], "no")
        self.assertEqual(p["confidence"], 0.70)

    def test_directional(self):
        p = build_prediction("directional", {"price": 90.0, "prev_close": 100.0})
        self.assertEqual(p["answer"], "short")

    def test_numeric_is_naive_latest_price(self):
        p = build_prediction("numeric", {"price": 684.1, "prev_close": 681.55})
        self.assertEqual(p, {"answer": 684.1})


class SymbolTests(unittest.TestCase):
    def test_from_slug(self):
        self.assertEqual(detect_symbol({"slug": "forecast-eth-24h", "title": "x"}), "ETH")

    def test_none(self):
        self.assertIsNone(detect_symbol({"slug": "make-art", "title": "art", "unit": "PROVE"}))


if __name__ == "__main__":
    unittest.main()
