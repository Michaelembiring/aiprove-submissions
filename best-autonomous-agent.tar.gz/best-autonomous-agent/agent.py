#!/usr/bin/env python3
"""Best-autonomous-agent — a fully autonomous AIProve agent.

Built on the same core loop as the sample agent (fetch skill.md -> own
keypair -> EIP-191 auth -> list bounties), then it keeps going on its own:

  for every open bounty:
    * fetch its detail (brief + submitKind)
    * classify it:
        - prediction bounties it understands  -> enter + submit a prediction
        - anything else                       -> log a SKIP with a reason
    * print a summary of acted / skipped

Prediction strategy (deliberately simple and honest — see README):
  * yes/no + probability (Brier) bounties: 24h momentum sign gives the
    answer; confidence is 0.50 + a small momentum-scaled bump, capped at
    0.70. It is a baseline heuristic, not an edge claim.
  * "one number" close-price bounties: the naive forecast — the latest
    price — submitted as the predicted close.
  * long/short directional bounties: the momentum sign.
  * prediction bounties whose answer shape it cannot produce honestly
    (e.g. "name 5 new tokens") are skipped, not guessed at.

SAFETY (see README "Safety" section):
  * This agent NEVER pays anything. In the open beta, entering and
    submitting are free; there is no payment, approval, transfer, or
    signing of anything except the EIP-191 login challenge.
  * Submitting to the live API requires the explicit `--live` flag.
    Without it the agent runs in dry-run mode and only prints what it
    WOULD do. `--mock fixtures/mock_bounties.json` runs fully offline
    against recorded-shaped responses.
  * Secrets (private key, session token) live only in local 0600,
    git-ignored files and are never printed.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.request

import requests
from eth_account import Account
from eth_account.messages import encode_defunct

HERE = os.path.dirname(os.path.abspath(__file__))
KEYPAIR_PATH = os.path.join(HERE, "keypair.json")
CREDENTIALS_PATH = os.path.join(HERE, "credentials.json")
DEFAULT_BASE = "https://aiprove.fun"
UA = {"User-Agent": "best-autonomous-agent/1.0"}
MAX_CONFIDENCE = 0.70  # never pretend to be surer than this baseline warrants


def write_secret(path: str, payload: dict) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        json.dump(payload, fh, indent=2)
    os.chmod(path, 0o600)


# ==========================================================================
# AIProve client (the sample-agent core, as a class)
# ==========================================================================
class AIProveClient:
    def __init__(self, base: str, session: requests.Session | None = None):
        self.base = base.rstrip("/")
        self.session = session or requests.Session()
        self.token: str | None = None

    def _request(self, method: str, url: str, **kwargs):
        kwargs.setdefault("timeout", 30)
        last_exc = None
        for attempt in range(1, 6):
            try:
                return self.session.request(method, url, **kwargs)
            except (requests.exceptions.ProxyError,
                    requests.exceptions.ConnectionError,
                    requests.exceptions.Timeout) as exc:
                last_exc = exc
                print(f"  [retry {attempt}/5] network error: {type(exc).__name__}")
                time.sleep(3 * attempt)
        raise RuntimeError(f"request failed after retries: {method} {url}") from last_exc

    def fetch_skill(self) -> str:
        resp = self._request("GET", f"{self.base}/skill.md", headers=UA)
        resp.raise_for_status()
        return resp.text

    def authenticate(self, acct: Account) -> None:
        resp = self._request("GET", f"{self.base}/api/auth/challenge",
                             params={"address": acct.address}, headers=UA)
        resp.raise_for_status()
        challenge = resp.json()["challenge"]
        signature = acct.sign_message(encode_defunct(text=challenge)).signature.hex()
        if not signature.startswith("0x"):
            signature = "0x" + signature
        resp = self._request("POST", f"{self.base}/api/auth/verify",
                             headers={**UA, "content-type": "application/json"},
                             data=json.dumps({"address": acct.address,
                                              "signature": signature}))
        resp.raise_for_status()
        body = resp.json()
        self.token = body.get("token")
        if not self.token:
            raise RuntimeError("verify response had no token")
        write_secret(CREDENTIALS_PATH, {
            "address": acct.address, "token": self.token,
            "expiresAt": body.get("expiresAt") or body.get("expires_at"),
        })

    def _auth_headers(self) -> dict:
        return {**UA, "content-type": "application/json",
                "Authorization": f"Bearer {self.token}"}

    def list_bounties(self) -> list[dict]:
        resp = self._request("GET", f"{self.base}/api/bounties",
                             params={"status": "open"}, headers=UA)
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else data.get("bounties", [])

    def get_bounty(self, slug: str) -> dict:
        resp = self._request("GET", f"{self.base}/api/bounties/{slug}", headers=UA)
        resp.raise_for_status()
        return resp.json()

    def enter(self, slug: str, handle: str) -> int:
        resp = self._request("POST", f"{self.base}/api/bounties/{slug}/enter",
                             headers=self._auth_headers(),
                             data=json.dumps({"handle": handle}))
        return resp.status_code

    def submit_prediction(self, slug: str, handle: str, prediction: dict) -> int:
        resp = self._request("POST", f"{self.base}/api/bounties/{slug}/submit",
                             headers=self._auth_headers(),
                             data=json.dumps({"prediction": prediction,
                                              "handle": handle}))
        return resp.status_code


class MockClient:
    """Offline stand-in with the same interface, fed by a fixtures file.

    Used for dry runs: list/detail come from the fixture, enter/submit are
    recorded (and reported as WOULD-DO by the caller), nothing is networked.
    """

    def __init__(self, fixtures: dict):
        self._bounties = fixtures["bounties"]
        self._details = fixtures["details"]

    def fetch_skill(self) -> str:
        return "(mock) skill.md — offline dry run, doc fetch skipped"

    def list_bounties(self) -> list[dict]:
        return self._bounties

    def get_bounty(self, slug: str) -> dict:
        return self._details[slug]

    def enter(self, slug: str, handle: str) -> int:  # pragma: no cover - dry-run guard
        raise AssertionError("MockClient must never be used for live enter")

    def submit_prediction(self, slug: str, handle: str, prediction: dict) -> int:
        raise AssertionError("MockClient must never be used for live submit")


# ==========================================================================
# Price feed
# ==========================================================================
class PriceFeed:
    """Latest price + previous close for a symbol.

    Live mode: CoinGecko (crypto, no key) and Stooq CSV (US stocks/ETFs,
    no key). Mock mode: values from the fixtures file. Failures return
    None, which makes the caller skip the bounty rather than guess.
    """

    COINGECKO_IDS = {"BTC": "bitcoin", "ETH": "ethereum"}
    STOOQ_SYMBOLS = {"SPY": "spy.us", "GLD": "gld.us", "NVDA": "nvda.us",
                     "META": "meta.us"}

    def __init__(self, mock_prices: dict | None = None):
        self.mock_prices = mock_prices

    def get(self, symbol: str) -> dict | None:
        symbol = symbol.upper()
        if self.mock_prices is not None:
            row = self.mock_prices.get(symbol)
            return dict(row) if row else None
        try:
            if symbol in self.COINGECKO_IDS:
                return self._coingecko(symbol)
            if symbol in self.STOOQ_SYMBOLS:
                return self._stooq(symbol)
        except Exception as exc:  # price failure -> skip, never guess
            print(f"      price fetch failed for {symbol}: {type(exc).__name__}")
            return None
        return None

    def _coingecko(self, symbol: str) -> dict | None:
        cid = self.COINGECKO_IDS[symbol]
        url = (f"https://api.coingecko.com/api/v3/coins/{cid}/market_chart"
               f"?vs_currency=usd&days=2")
        with urllib.request.urlopen(url, timeout=20) as fh:
            prices = json.load(fh)["prices"]  # [[ts_ms, price], ...]
        if len(prices) < 2:
            return None
        now = prices[-1][1]
        day_ago = min(prices, key=lambda p: abs(p[0] - (prices[-1][0] - 86_400_000)))[1]
        return {"price": float(now), "prev_close": float(day_ago),
                "source": "coingecko market_chart (2d)"}

    def _stooq(self, symbol: str) -> dict | None:
        sym = self.STOOQ_SYMBOLS[symbol]
        url = f"https://stooq.com/q/d/l/?s={sym}&i=d"
        with urllib.request.urlopen(url, timeout=20) as fh:
            lines = fh.read().decode().strip().splitlines()
        rows = [ln.split(",") for ln in lines[1:] if ln.strip()]
        if len(rows) < 2:
            return None
        # Date,Open,High,Low,Close,Volume
        return {"price": float(rows[-1][4]), "prev_close": float(rows[-2][4]),
                "source": "stooq daily csv"}


# ==========================================================================
# Prediction logic — simple, disclosed, honest baselines
# ==========================================================================
SYMBOL_HINTS = ("BTC", "ETH", "SPY", "GLD", "NVDA", "META")


def detect_symbol(bounty: dict) -> str | None:
    haystack = f"{bounty.get('slug', '')} {bounty.get('title', '')}".upper()
    for sym in SYMBOL_HINTS:
        if sym in haystack:
            return sym
    unit = str(bounty.get("unit", "")).upper()
    return unit if unit in SYMBOL_HINTS else None


def classify_prediction(bounty: dict, detail: dict) -> str:
    """Return 'yesno' | 'numeric' | 'directional' | 'unsupported'.

    Only call for bounties whose submitKind is 'prediction'. The shape is
    read off the brief, which states the required answer in plain words.
    """
    brief = (detail.get("bounty", detail).get("brief") or "").lower()
    if "long or short" in brief or "long/short" in brief:
        return "directional"
    if ("yes or no" in brief or "yes/no" in brief or "probability" in brief
            or "brier" in brief):
        return "yesno"
    if ("one number" in brief or "single number" in brief or "a number" in brief
            or "close" in brief):
        return "numeric"
    return "unsupported"


def build_prediction(shape: str, price_row: dict) -> dict:
    """Build the prediction payload from a price row.

    Momentum = (price - prev_close) / prev_close.
      yesno:       answer follows the momentum sign; confidence is a small,
                   capped function of |momentum| (baseline, not an edge).
      directional: 'long' if momentum >= 0 else 'short', same confidence.
      numeric:     naive forecast — the latest price IS the predicted close.
    """
    price = float(price_row["price"])
    prev = float(price_row["prev_close"])
    momentum = (price - prev) / prev if prev else 0.0
    confidence = round(min(MAX_CONFIDENCE, 0.50 + abs(momentum) * 5), 2)
    if shape == "yesno":
        return {"answer": "yes" if momentum >= 0 else "no",
                "confidence": confidence}
    if shape == "directional":
        return {"answer": "long" if momentum >= 0 else "short",
                "confidence": confidence}
    if shape == "numeric":
        return {"answer": round(price, 2)}
    raise ValueError(f"cannot build a prediction for shape={shape!r}")


def skip_reason(bounty: dict, detail: dict) -> str:
    kind = detail.get("submitKind") or "unknown"
    lane = bounty.get("lane")
    if kind == "repo":
        return ("repo@commit task — needs a built code artefact, not an "
                "autonomous prediction; out of this agent's scope")
    if kind == "link":
        return ("link task (PosterJudge) — needs a created artefact/link "
                "produced outside the API loop")
    if kind == "bughunt":
        return "bug-hunt task — needs code analysis of an external repo, not a prediction"
    if kind == "referral":
        return "referral task — growth activity, not a submittable prediction"
    if lane == "PosterJudge":
        return "PosterJudge (subjective) task — no objective payload this agent can produce"
    return f"unsupported submitKind={kind!r}"


# ==========================================================================
# The autonomous loop
# ==========================================================================
def run(client, prices: PriceFeed, handle: str, live: bool) -> dict:
    mode = "LIVE" if live else "DRY-RUN"
    print(f"=== best-autonomous-agent loop ({mode}) ===")
    bounties = client.list_bounties()
    print(f"open bounties: {len(bounties)}")
    acted, skipped = [], []
    for bounty in bounties:
        slug = bounty["slug"]
        detail = client.get_bounty(slug)
        kind = detail.get("submitKind")
        if kind != "prediction":
            reason = skip_reason(bounty, detail)
            print(f"SKIP  {slug:<28} kind={kind} — {reason}")
            skipped.append((slug, reason))
            continue
        shape = classify_prediction(bounty, detail)
        if shape == "unsupported":
            reason = ("prediction shape this agent cannot produce honestly "
                      "(no yes/no, numeric-close, or long/short form in the brief)")
            print(f"SKIP  {slug:<28} kind=prediction shape=unsupported — {reason}")
            skipped.append((slug, reason))
            continue
        symbol = detect_symbol(bounty)
        price_row = prices.get(symbol) if symbol else None
        if price_row is None:
            reason = f"no price available for symbol={symbol!r} — refusing to guess"
            print(f"SKIP  {slug:<28} kind=prediction shape={shape} — {reason}")
            skipped.append((slug, reason))
            continue
        prediction = build_prediction(shape, price_row)
        print(f"ACT   {slug:<28} kind=prediction shape={shape} symbol={symbol} "
              f"price={price_row['price']} prev_close={price_row['prev_close']} "
              f"source={price_row.get('source', 'mock fixture')}")
        print(f"      prediction: {json.dumps(prediction)}")
        if live:
            code = client.enter(slug, handle)
            print(f"      enter -> HTTP {code}")
            code = client.submit_prediction(slug, handle, prediction)
            print(f"      submit -> HTTP {code}")
            acted.append((slug, f"submitted {prediction}"))
        else:
            print(f"      WOULD enter + submit (dry-run, nothing sent)")
            acted.append((slug, f"would submit {prediction}"))
    print("=== SUMMARY ===")
    print(f"acted:   {len(acted)}")
    for slug, what in acted:
        print(f"  - {slug}: {what}")
    print(f"skipped: {len(skipped)}")
    for slug, why in skipped:
        print(f"  - {slug}: {why}")
    return {"acted": acted, "skipped": skipped}


def load_or_create_keypair() -> Account:
    if os.path.exists(KEYPAIR_PATH):
        with open(KEYPAIR_PATH) as fh:
            return Account.from_key(json.load(fh)["private_key"])
    acct = Account.create()
    write_secret(KEYPAIR_PATH, {
        "address": acct.address, "private_key": acct.key.hex(),
        "note": "Autonomous agent's OWN keypair. Local only, git-ignored, never funded.",
    })
    return acct


def main() -> int:
    ap = argparse.ArgumentParser(description="Fully autonomous AIProve agent")
    ap.add_argument("--base", default=os.environ.get("API_BASE_URL", DEFAULT_BASE))
    ap.add_argument("--live", action="store_true",
                    help="actually enter + submit to the live API "
                         "(default: dry-run, nothing is sent)")
    ap.add_argument("--mock", metavar="FILE",
                    help="offline fixtures file (implies dry-run; no network at all)")
    ap.add_argument("--handle", default=None)
    args = ap.parse_args()
    if args.live and args.mock:
        ap.error("--live and --mock are mutually exclusive")

    if args.mock:
        with open(args.mock) as fh:
            fixtures = json.load(fh)
        print(f"mock fixtures loaded from {args.mock}: "
              f"{len(fixtures['bounties'])} bounties, "
              f"{len(fixtures.get('prices', {}))} mock prices")
        print("identity: skipped in mock mode (no keypair, no auth, no network)")
        client = MockClient(fixtures)
        prices = PriceFeed(mock_prices=fixtures.get("prices", {}))
        run(client, prices, handle=args.handle or "autonomous-mock", live=False)
        print("DRY-RUN COMPLETE — no API writes were made.")
        return 0

    session = requests.Session()
    client = AIProveClient(args.base, session)
    skill = client.fetch_skill()
    print(f"skill.md fetched ({len(skill)} chars); signing scheme: "
          f"{'EIP-191' if 'EIP-191' in skill else 'unknown'}")
    acct = load_or_create_keypair()
    handle = args.handle or f"autonomous-{acct.address[2:10].lower()}"
    print(f"agent address: {acct.address}  handle: {handle}")
    if args.live:
        client.authenticate(acct)
        print("AUTH OK (live mode)")
        run(client, PriceFeed(), handle, live=True)
    else:
        print("dry-run against the live read-only API: no auth, no writes")
        run(client, PriceFeed(), handle, live=False)
        print("DRY-RUN COMPLETE — no API writes were made.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
