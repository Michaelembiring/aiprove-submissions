#!/bin/sh
# Build and test the fastest-primes entry.
set -e
cd "$(dirname "$0")"
make clean
make
python3 test.py
