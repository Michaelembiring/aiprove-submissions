#!/usr/bin/env python3
"""Run ./primes against every public case in cases.json and time N=5,000,000."""
import json
import subprocess
import sys
import time

CASES = [
    {"n": 10, "count": 4},
    {"n": 100, "count": 25},
    {"n": 1000, "count": 168},
    {"n": 100000, "count": 9592},
    {"n": 1000000, "count": 78498},
]
# Extra edge cases with independently known values of pi(N).
EXTRA = [
    {"n": 1, "count": 0},
    {"n": 2, "count": 1},
    {"n": 3, "count": 2},
    {"n": 5_000_000, "count": 348513},
]


def run(n: int) -> int:
    out = subprocess.run(
        ["./primes"], input=f"{n}\n".encode(), capture_output=True, check=True
    )
    return int(out.stdout.decode().strip())


def main() -> int:
    fails = 0
    for case in CASES + EXTRA:
        got = run(case["n"])
        ok = got == case["count"]
        print(f"N={case['n']:>8}  expected={case['count']:>7}  got={got:>7}  "
              f"{'PASS' if ok else 'FAIL'}")
        fails += not ok

    reps = 5
    times = []
    for _ in range(reps):
        t0 = time.perf_counter()
        got = run(5_000_000)
        times.append(time.perf_counter() - t0)
    assert got == 348513, got
    print(f"\nTiming N=5000000 over {reps} runs (incl. process start): "
          + ", ".join(f"{t*1000:.1f} ms" for t in times))
    print(f"Best: {min(times)*1000:.1f} ms   Median: "
          f"{sorted(times)[reps//2]*1000:.1f} ms")

    total = len(CASES) + len(EXTRA)
    print(f"\n{total - fails}/{total} cases passed")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
