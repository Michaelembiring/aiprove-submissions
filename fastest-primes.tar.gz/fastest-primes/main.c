// fastest-primes: read N on stdin, print pi(N) = number of primes <= N.
//
// Method: odd-only Sieve of Eratosthenes on a byte array.
//  - Only odd numbers are stored: index k represents the number 2*k+1,
//    so memory is N/2 bytes (2.5 MB at N = 5,000,000) and every even
//    multiple is skipped for free.
//  - Marking for prime p starts at p*p and strides by 2*p (odd multiples
//    only), which halves the marking work again.
//  - Input is parsed by hand from a raw read(2) and output is formatted
//    by hand into a write(2): no stdio / scanf / printf overhead.
// Build: gcc -O3 -march=native -o primes main.c   (see Makefile)

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(void) {
    // ---- parse N (first integer on stdin) ----
    char inbuf[64];
    ssize_t got = read(STDIN_FILENO, inbuf, sizeof(inbuf));
    if (got <= 0) return 0;
    long n = 0;
    ssize_t pos = 0;
    while (pos < got && (inbuf[pos] == ' ' || inbuf[pos] == '\n' ||
                         inbuf[pos] == '\r' || inbuf[pos] == '\t'))
        pos++;
    while (pos < got && inbuf[pos] >= '0' && inbuf[pos] <= '9') {
        n = n * 10 + (inbuf[pos] - '0');
        pos++;
    }

    if (n < 2) {
        (void)!write(STDOUT_FILENO, "0\n", 2);
        return 0;
    }

    // ---- odd-only sieve ----
    // comp[k] != 0  <=>  2*k+1 is composite.  k in [0, half), half=(n+1)/2.
    size_t half = (size_t)(n + 1) / 2;
    uint8_t *comp = (uint8_t *)malloc(half);
    if (!comp) return 1;
    memset(comp, 0, half);
    comp[0] = 1; // number 1 is not prime

    long limit = 0;
    while ((limit + 1) * (limit + 1) <= n) limit++; // floor(sqrt(n))

    for (long p = 3; p <= limit; p += 2) {
        if (comp[p >> 1]) continue;
        long step = p << 1;          // skip even multiples
        for (long m = p * p; m <= n; m += step)
            comp[m >> 1] = 1;
    }

    // ---- count: prime 2 plus every unmarked odd ----
    long count = 1; // the prime 2
    for (size_t k = 1; k < half; k++)
        count += !comp[k];
    free(comp);

    // ---- print count ----
    char outbuf[32];
    int len = 0;
    char rev[32];
    int r = 0;
    long c = count;
    if (c == 0) rev[r++] = '0';
    while (c > 0) {
        rev[r++] = (char)('0' + (c % 10));
        c /= 10;
    }
    while (r > 0) outbuf[len++] = rev[--r];
    outbuf[len++] = '\n';
    (void)!write(STDOUT_FILENO, outbuf, (size_t)len);
    return 0;
}
