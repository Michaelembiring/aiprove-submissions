# fastest-primes

Reads an integer `N` (1 ≤ N ≤ 5,000,000) on stdin and prints the number of
primes ≤ N (π(N)) on stdout.

## Entry / run command

- Source: `main.c` (C, no dependencies)
- Build: `make` — i.e. `gcc -O3 -march=native -o primes main.c`
- Run: `./primes` with `N` on stdin, e.g. `echo 1000000 | ./primes` → `78498`

## How it works

Odd-only Sieve of Eratosthenes on a byte array:

- Only odd numbers are stored — index `k` represents `2k+1` — so memory is
  N/2 bytes (2.5 MB at N = 5,000,000) and all even multiples are skipped
  for free.
- Marking for a prime `p` starts at `p*p` and strides by `2p` (odd
  multiples only), halving the marking work again.
- Input is parsed by hand from a raw `read(2)` and the result is formatted
  by hand into a `write(2)` — no stdio, `scanf`, or `printf` overhead in
  the timed path.

## Tests

`./build_and_test.sh` (or `make test`) runs `test.py`, which checks all
5 public cases from `cases.json` plus edge cases N = 1, 2, 3 and the max
N = 5,000,000 (π = 348,513).

Result: **9/9 cases passed.**

Timing at N = 5,000,000 (wall clock, including process start, this
machine): **best 6.1 ms, median 6.4 ms** over 5 runs. Full build + test
output is in `transcript.txt`.
