"""Dataset exploration for the eth-pnl-fixed challenge (printed in transcript)."""
import numpy as np
import pandas as pd

bars = pd.read_csv("data/bars.csv")
close = bars["close"]
logret = np.log(close / close.shift(1))

print(f"Bars: {len(bars)} (1-minute OHLCV), columns: {list(bars.columns)}")
print(f"Close range: min {close.min():.2f} | max {close.max():.2f}")
print(f"First close: {close.iloc[0]:.2f} -> last close: {close.iloc[-1]:.2f} "
      f"({(close.iloc[-1] / close.iloc[0] - 1) * 100:+.2f}% buy-and-hold move)")
print(f"Per-minute log-return std: {logret.std():.5f} "
      f"(~{logret.std() * np.sqrt(1440 * 365) * 100:.0f}% annualised)")
print(f"Volume (ETH/bar): mean {bars['volume'].mean():.1f}, "
      f"median {bars['volume'].median():.1f}, max {bars['volume'].max():.1f}")
print(f"Mean absolute 1-min move: {(close.diff().abs() / close).mean() * 10000:.1f} bps "
      f"— vs 10 bps taker fee per side, so churn is punished hard.")
