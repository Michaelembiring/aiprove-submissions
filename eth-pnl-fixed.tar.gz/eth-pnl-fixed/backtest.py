"""Backtest engine + runner for the AIProve `eth-pnl-fixed` challenge.

Execution / accounting model (faithful to the challenge README's cost model:
"net PnL after costs — maker + taker fees, slippage scaled by size", with
"no phantom fills"; the challenge README names the cost categories but
publishes no numeric rates, so the exact rates used here are declared in
COSTS below and in results.json):

  * Signals are decided at the close of bar t and executed at the OPEN of
    bar t+1 (never the same bar, never a price the bar didn't trade at).
  * All executions are market orders, so the TAKER fee applies:
    0.10% (10 bps) of traded notional — the standard Binance spot taker fee.
    The MAKER fee (0.08%) is declared for completeness; this strategy places
    no passive/limit orders, so the maker rate is never charged.
  * Slippage scales with trade size, as the README specifies:
        slippage_bps = min(BASE_SLIPPAGE_BPS
                           + SLIPPAGE_SIZE_COEF_BPS * participation, CAP_BPS)
        participation = |ETH traded| / (volume of the execution bar, in ETH)
    Buys fill at open * (1 + slippage), sells at open * (1 - slippage).
  * Positions are share quantities fixed at entry (sized off equity at the
    moment of the trade); the position is NOT rebalanced bar-to-bar, so a
    held position incurs no phantom turnover or costs.
  * Short positions are held as a negative ETH quantity against cash
    (standard long/short backtest accounting, 1x max, no leverage, no
    funding/borrow fee in the stated cost model).
  * Any position still open after the last bar is closed at the last close,
    paying the same fee + slippage, so reported PnL is fully realised.
  * Max drawdown is measured on the mark-to-market equity curve (per-bar
    close), in USD and as % of the running peak.

Usage:  python3 backtest.py [--bars data/bars.csv] [--out results.json]
"""

from __future__ import annotations

import argparse
import json

import numpy as np
import pandas as pd

from strategy import ENTRY_WINDOW, EXIT_WINDOW, generate_positions

STARTING_CAPITAL = 10_000.0  # USDT

COSTS = {
    "taker_fee_rate": 0.0010,        # 10 bps of traded notional, every fill
    "maker_fee_rate": 0.0008,        # 8 bps — declared; never charged (no limit orders)
    "slippage_base_bps": 5.0,        # paid even on a tiny order
    "slippage_size_coef_bps": 50.0,  # +50 bps at 100% of one bar's volume
    "slippage_cap_bps": 50.0,        # slippage never exceeds 50 bps
    "fee_type_applied": "taker (market orders at next bar open)",
}


def slippage_rate(trade_eth: float, bar_volume_eth: float) -> float:
    participation = abs(trade_eth) / bar_volume_eth if bar_volume_eth > 0 else 1.0
    bps = COSTS["slippage_base_bps"] + COSTS["slippage_size_coef_bps"] * participation
    return min(bps, COSTS["slippage_cap_bps"]) / 10_000.0


def run_backtest(bars: pd.DataFrame, positions: pd.Series) -> dict:
    opens = bars["open"].to_numpy(dtype=float)
    closes = bars["close"].to_numpy(dtype=float)
    volumes = bars["volume"].to_numpy(dtype=float)
    targets = positions.to_numpy(dtype=float)
    n = len(bars)

    cash = STARTING_CAPITAL
    qty = 0.0            # ETH held (negative = short)
    current = 0.0        # position state we are currently in
    trades = []          # each executed fill
    total_fees = 0.0
    total_slippage = 0.0
    equity = np.empty(n)

    def execute(want: float, price: float, volume: float, bar: int, reason: str) -> None:
        nonlocal cash, qty, current, total_fees, total_slippage
        equity_now = cash + qty * price
        target_qty = want * equity_now / price  # position fraction of equity
        delta = target_qty - qty
        notional = abs(delta * price)
        if notional < 1.0:  # sub-$1 adjustment: not a trade
            return
        slip = slippage_rate(delta, volume)
        fill_price = price * (1.0 + slip) if delta > 0 else price * (1.0 - slip)
        fee = notional * COSTS["taker_fee_rate"]
        cash -= delta * fill_price + fee
        qty = target_qty
        current = want
        total_fees += fee
        total_slippage += notional * slip
        trades.append({
            "bar": int(bar), "side": "buy" if delta > 0 else "sell",
            "eth": round(float(delta), 6), "price": round(float(fill_price), 4),
            "notional_usdt": round(float(notional), 2), "fee_usdt": round(float(fee), 4),
            "slippage_bps": round(float(slip * 10_000), 3), "reason": reason,
        })

    for t in range(n):
        if t > 0 and targets[t - 1] != current:
            execute(float(targets[t - 1]), opens[t], volumes[t], t, "signal")
        equity[t] = cash + qty * closes[t]

    if qty != 0.0:  # close out at the final close, paying full costs
        execute(0.0, closes[-1], volumes[-1], n - 1, "final_close")
        equity[-1] = cash

    peak = np.maximum.accumulate(equity)
    drawdown = equity - peak
    max_dd_usd = float(drawdown.min())
    max_dd_pct = float((drawdown / peak).min() * 100.0)
    net_pnl = float(equity[-1] - STARTING_CAPITAL)

    return {
        "net_pnl_usdt": round(net_pnl, 2),
        "net_return_pct": round(net_pnl / STARTING_CAPITAL * 100.0, 4),
        "starting_capital_usdt": STARTING_CAPITAL,
        "ending_equity_usdt": round(float(equity[-1]), 2),
        "num_trades": len(trades),
        "max_drawdown_usdt": round(max_dd_usd, 2),
        "max_drawdown_pct": round(max_dd_pct, 4),
        "total_fees_usdt": round(total_fees, 2),
        "total_slippage_usdt": round(total_slippage, 2),
        "trades": trades,
        "equity_curve_last": round(float(equity[-1]), 2),
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="eth-pnl-fixed backtest")
    ap.add_argument("--bars", default="data/bars.csv")
    ap.add_argument("--out", default="results.json")
    args = ap.parse_args()

    bars = pd.read_csv(args.bars)
    positions = generate_positions(bars)
    result = run_backtest(bars, positions)

    output = {
        "challenge": "eth-pnl-fixed",
        "dataset": {"file": args.bars, "bars": int(len(bars)),
                    "first_close": float(bars["close"].iloc[0]),
                    "last_close": float(bars["close"].iloc[-1])},
        "strategy": {
            "name": "Donchian channel breakout (Turtle-style), long/short, 1x cap",
            "entry_window_min": ENTRY_WINDOW, "exit_window_min": EXIT_WINDOW,
            "execution": "signal at close of bar t, market fill at open of bar t+1",
        },
        "costs": COSTS,
        **{k: v for k, v in result.items() if k != "trades"},
        "trades": result["trades"],
    }
    with open(args.out, "w") as fh:
        json.dump(output, fh, indent=2)

    print(f"Bars:            {len(bars)}")
    print(f"Strategy:        Donchian {ENTRY_WINDOW}m entry / {EXIT_WINDOW}m exit, long/short, 1x")
    print(f"Starting capital: {STARTING_CAPITAL:,.2f} USDT")
    print(f"Net PnL (after fees + slippage): {output['net_pnl_usdt']:+,.2f} USDT "
          f"({output['net_return_pct']:+.3f}%)")
    print(f"Trades (fills):  {output['num_trades']}")
    print(f"Max drawdown:    {output['max_drawdown_usdt']:,.2f} USDT ({output['max_drawdown_pct']:.3f}%)")
    print(f"Fees paid:       {output['total_fees_usdt']:,.2f} USDT | "
          f"Slippage cost: {output['total_slippage_usdt']:,.2f} USDT")
    for tr in result["trades"]:
        print(f"  bar {tr['bar']:>4}  {tr['side']:<4} {tr['eth']:+9.4f} ETH @ {tr['price']:>9.2f} "
              f"notional {tr['notional_usdt']:>9.2f}  fee {tr['fee_usdt']:.2f}  "
              f"slip {tr['slippage_bps']:.2f}bps  ({tr['reason']})")
    print(f"Results written to {args.out}")


if __name__ == "__main__":
    main()
