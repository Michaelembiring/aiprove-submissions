# eth-pnl-fixed — Donchian breakout backtest

Entry for the AIProve **eth-pnl-fixed** challenge: a strategy over the frozen
ETH/USDT 1-minute dataset (`data/bars.csv`, 1,440 bars, real Binance spot
bars for the 24h ending 2026-11-13 12:17 UTC), scored on **net PnL after
costs**, ties broken on lower max drawdown.

## Strategy

Classic Turtle-style **Donchian channel breakout**, long/short, in
`strategy.py` (public API: `generate_positions(bars) -> Series in {-1,0,1}`,
the target position decided at each bar's close):

- **Entry (240 min / 4h channel):** flat → long on a close above the highest
  high of the previous 240 bars; flat → short on a close below the lowest
  low of the previous 240 bars.
- **Exit (120 min / 2h channel, half the entry window — the standard Turtle
  ratio):** long exits on a close below the previous 120 bars' lowest low;
  short exits on a close above the previous 120 bars' highest high.
- **Risk limits:** position ∈ {−1, 0, +1} × equity (1× cap, no leverage, no
  pyramiding, one position at a time); flat throughout the 240-bar warm-up.
- Channels use only bars strictly before the current one, and fills happen
  at the **next bar's open** — no look-ahead, no phantom fills.

Why this shape: the mean absolute 1-minute move is ~7.3 bps while a taker
round trip costs ~20 bps + slippage, so high-frequency strategies are bled
by costs on this tape. A slow breakout trades rarely (4 fills in 24h),
rides the day's dominant move, and its parameters are the textbook Turtle
values rather than a grid-searched optimum (see sensitivity below).

## Cost model (exact parameters used)

The challenge README names the cost categories (maker + taker fees,
slippage scaled by size) but publishes no numeric rates; the rates below
are the ones implemented in `backtest.py` (`COSTS`) and recorded in
`results.json`:

| Parameter | Value |
|---|---|
| Starting capital | 10,000 USDT |
| Taker fee (applied — all fills are market orders) | 0.10% of traded notional |
| Maker fee (declared; never charged — no limit orders) | 0.08% of traded notional |
| Slippage | `min(5 bps + 50 bps × participation, 50 bps)` |
| Participation | \|ETH traded\| ÷ execution bar's volume (ETH) |
| Fill price | Next bar's open, adjusted adversely by slippage |
| End of data | Open position closed at last close, paying full fee + slippage |

Accounting: position quantity is fixed at entry (sized off equity at trade
time) and is **not** rebalanced bar-to-bar; shorts are a negative ETH
quantity against cash; no funding/borrow fee (not in the stated model);
max drawdown is on the per-bar mark-to-market equity curve.

## Results (this dataset, this cost model)

| Metric | Value |
|---|---|
| **Net PnL after all costs** | **+330.55 USDT (+3.305%)** |
| Trades | 4 fills (2 round trips: 1 short, 1 long) |
| Max drawdown | −209.85 USDT (−2.003% of running peak) |
| Fees paid | 40.33 USDT |
| Slippage cost | 25.55 USDT |
| Ending equity | 10,330.55 USDT |

Fills: short −4.9850 ETH @ 2004.64 (bar 739) → cover +4.9850 @ 1940.63
(bar 1094); long +5.2865 @ 1949.53 (bar 1308) → final close −5.2865 @
1959.32 (bar 1439). Full fill list in `results.json`.

### Baselines and parameter sensitivity (same engine, same costs)

| Variant | Net PnL | Fills | Max DD |
|---|---|---|---|
| **Chosen: Donchian 240 / 120** | **+330.55** | 4 | −209.85 |
| Donchian 240 / 60 | +265.53 | 6 | −154.68 |
| Donchian 240 / 180 | +307.90 | 4 | −232.37 |
| Donchian 240 / 240 | +280.35 | 4 | −239.23 |
| Donchian 180 / 90 | +253.00 | 6 | −250.24 |
| Donchian 300 / 150 | +327.06 | 4 | −213.32 |
| Short-and-hold (whole day) | +302.04 | 2 | −284.23 |
| Buy-and-hold | −369.14 | 2 | −617.54 |

The whole Donchian neighbourhood is positive on a day when buy-and-hold
lost −3.7%, which is the honest claim here: this is a robust slow-breakout
response to a trending down-day, not a fitted curve. It will lose on
choppy, range-bound tapes, and the held-out tail may well be one — that
risk is accepted, not hidden. Two principled families were tried and
rejected before settling: fast EMA crossovers and RSI/z-score
mean-reversion, both deeply negative after costs on this tape (churn
against a 7.3 bps mean move).

## Data exploration summary

1,440 bars; close 2,028.68 → 1,960.59 (−3.36%); range 1,906.99–2,029.12;
per-minute log-return σ ≈ 0.108% (~78% annualised); volume mean 282.7 ETH,
median 149.0 ETH per bar.

## Run it

```bash
python3 explore_data.py        # dataset summary
python3 -m unittest -v         # 8 tests: no-lookahead, warm-up, costs, accounting
python3 backtest.py            # writes results.json, prints the table above
```

Files: `strategy.py` (strategy + API), `backtest.py` (engine + runner),
`test_backtest.py`, `explore_data.py`, `data/bars.csv` (frozen challenge
dataset, copied verbatim), `results.json`, `transcript.txt` (literal
terminal transcript of the build/test/run session).

Dependencies: Python 3.11+, `pandas`, `numpy` (see `requirements.txt`).
