"""Tests: run with `python3 -m unittest -v` (stdlib only, plus pandas/numpy)."""
import unittest

import numpy as np
import pandas as pd

from backtest import COSTS, run_backtest, slippage_rate
from strategy import ENTRY_WINDOW, generate_positions


def flat_bars(n=600, price=2000.0):
    return pd.DataFrame({
        "minute": range(n), "open": price, "high": price,
        "low": price, "close": price, "volume": 100.0,
    })


class TestStrategy(unittest.TestCase):
    def test_flat_market_never_trades(self):
        pos = generate_positions(flat_bars())
        self.assertTrue((pos == 0).all())

    def test_warmup_is_flat(self):
        bars = flat_bars()
        bars.loc[10:, "close"] = 2100.0  # jump during warm-up must be ignored
        pos = generate_positions(bars)
        self.assertTrue((pos.iloc[:ENTRY_WINDOW] == 0).all())

    def test_breakout_goes_long_and_short(self):
        bars = flat_bars(1100)
        bars.loc[300:599, ["open", "high", "low", "close"]] = 2100.0
        bars.loc[600:849, ["open", "high", "low", "close"]] = 1900.0
        bars.loc[850:, ["open", "high", "low", "close"]] = 1800.0
        pos = generate_positions(bars)
        self.assertIn(1.0, set(pos))    # long after the up-break
        self.assertIn(-1.0, set(pos))   # short after the down-break

    def test_no_lookahead(self):
        bars = pd.read_csv("data/bars.csv")
        full = generate_positions(bars)
        truncated = generate_positions(bars.iloc[:1000].copy())
        pd.testing.assert_series_equal(full.iloc[:1000], truncated, check_names=False)


class TestCostsAndAccounting(unittest.TestCase):
    def test_slippage_scales_with_size_and_caps(self):
        small = slippage_rate(1.0, 100.0)
        big = slippage_rate(50.0, 100.0)
        huge = slippage_rate(10_000.0, 100.0)
        self.assertLess(small, big)
        self.assertAlmostEqual(huge, COSTS["slippage_cap_bps"] / 10_000.0)

    def test_round_trip_on_flat_market_loses_only_costs(self):
        bars = flat_bars(10)
        pos = pd.Series([1, 1, 1, 1, 1, 0, 0, 0, 0, 0], dtype=float)
        r = run_backtest(bars, pos)
        self.assertEqual(r["num_trades"], 2)  # entry + exit, nothing else
        self.assertLess(r["net_pnl_usdt"], 0)  # fees + slippage are a real drag
        self.assertAlmostEqual(
            r["net_pnl_usdt"] + r["total_fees_usdt"] + r["total_slippage_usdt"],
            0.0, places=1)

    def test_holding_a_position_charges_nothing_extra(self):
        bars = flat_bars(100)
        pos = pd.Series([1.0] * 100)
        r = run_backtest(bars, pos)
        self.assertEqual(r["num_trades"], 2)  # open once, final close once

    def test_real_dataset_result_is_internally_consistent(self):
        bars = pd.read_csv("data/bars.csv")
        r = run_backtest(bars, generate_positions(bars))
        self.assertAlmostEqual(
            r["ending_equity_usdt"] - 10_000.0, r["net_pnl_usdt"], places=2)
        self.assertLessEqual(r["max_drawdown_usdt"], 0.0)
        self.assertEqual(r["num_trades"], len(r["trades"]))


if __name__ == "__main__":
    unittest.main()
