"""Strategy for the AIProve `eth-pnl-fixed` challenge.

Classic Turtle-style Donchian channel breakout on ETH/USDT 1-minute bars:

  * Entry channel: 240 minutes (4 hours). When flat, go LONG if the close
    breaks above the highest high of the previous 240 bars, go SHORT if the
    close breaks below the lowest low of the previous 240 bars.
  * Exit channel: 120 minutes (2 hours, half the entry window — the standard
    Turtle ratio). A long exits when the close crosses below the lowest low
    of the previous 120 bars; a short exits when the close crosses above the
    highest high of the previous 120 bars.
  * Risk limits: position is always in {-1, 0, +1} x account equity
    (no leverage, no pyramiding, one position at a time), and the strategy
    is flat during the 240-bar warm-up, so it can never trade on partial
    channels.
  * Channels are computed from bars STRICTLY BEFORE the current bar
    (shifted by one), and the backtest engine executes a signal decided at
    the close of bar t at the OPEN of bar t+1. No look-ahead anywhere.

Public API
----------
generate_positions(bars) -> pandas Series of target positions in {-1, 0, 1},
indexed like `bars`. This is the function the sandbox / backtest replays.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

ENTRY_WINDOW = 240   # minutes; 4h breakout channel
EXIT_WINDOW = 120    # minutes; 2h exit channel (half the entry window)
MAX_POSITION = 1.0   # never more than 1x equity, long or short


def generate_positions(bars: pd.DataFrame) -> pd.Series:
    """Return the target position (-1, 0 or +1) decided at each bar's close."""
    close = bars["close"].to_numpy(dtype=float)
    high = bars["high"].to_numpy(dtype=float)
    low = bars["low"].to_numpy(dtype=float)
    n = len(bars)

    # Channels use only bars strictly before t (rolling window, then shift 1).
    entry_hi = pd.Series(high).rolling(ENTRY_WINDOW).max().shift(1).to_numpy()
    entry_lo = pd.Series(low).rolling(ENTRY_WINDOW).min().shift(1).to_numpy()
    exit_hi = pd.Series(high).rolling(EXIT_WINDOW).max().shift(1).to_numpy()
    exit_lo = pd.Series(low).rolling(EXIT_WINDOW).min().shift(1).to_numpy()

    positions = np.zeros(n, dtype=float)
    current = 0.0
    for t in range(n):
        if np.isnan(entry_hi[t]):
            current = 0.0  # warm-up: not enough history for a full channel
        elif current == 0.0:
            if close[t] > entry_hi[t]:
                current = MAX_POSITION
            elif close[t] < entry_lo[t]:
                current = -MAX_POSITION
        elif current > 0.0:
            if close[t] < exit_lo[t]:
                current = 0.0
        else:  # current < 0
            if close[t] > exit_hi[t]:
                current = 0.0
        positions[t] = current
    return pd.Series(positions, index=bars.index, name="position")
