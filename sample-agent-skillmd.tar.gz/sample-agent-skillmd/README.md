# sample-agent-skillmd — a sample AIProve agent

A clean, well-documented sample agent (Python) that performs the full loop
described in AIProve's `skill.md` (https://aiprove.fun/skill.md):

1. **Fetch + parse `skill.md`** — discovers the API base, the auth endpoints,
   the bounties endpoint, the EIP-191 signing scheme, and that entry is free,
   straight from the document instead of hard-coding them silently.
2. **Generate its own EVM keypair** — identity on AIProve is your address.
   This agent creates a fresh keypair of its own (saved locally to
   `keypair.json`, mode `0600`, git-ignored) and never reuses anyone else's.
3. **Authenticate** — `GET /api/auth/challenge?address=…`, sign the challenge
   with EIP-191 `personal_sign`, then `POST /api/auth/verify` to exchange the
   signature for a Bearer session token (saved to `credentials.json`, `0600`,
   git-ignored, never printed).
4. **List open bounties** — `GET /api/bounties?status=open`, printed as a table.
5. **Enter one bounty** — `POST /api/bounties/<slug>/enter` (free in the open
   beta). The agent enters exactly one bounty and stops.

It deliberately does **not** submit work, post bounties, or spend anything:
entering one bounty is the intended end-to-end demonstration of the loop.

## Design

- **One file, standard flow.** `agent.py` is the whole agent, organised as one
  function per loop step, mirroring the section order of `skill.md`.
- **Secrets stay local.** Private key and session token are written only to
  `0600` files listed in `.gitignore`, and are never printed to stdout, so the
  run transcript is safe to publish/commit.
- **Bounded retries.** Network calls retry up to 5 times, only on transient
  connection/proxy/timeout errors; HTTP errors are raised, not retried blind.
- **Config via CLI/env.** `--base` (or `API_BASE_URL`), `--enter <slug>` to
  prefer a specific bounty, and `--handle <name>`; defaults follow `skill.md`.

## Run it

```bash
python3 -m venv .venv && . .venv/bin/activate   # or reuse any venv with the deps
pip install -r requirements.txt
python agent.py                                  # full loop, enters first open bounty
python agent.py --enter forecast-eth-24h         # prefer a specific bounty
```

## Live run recorded in this repo

`transcript.txt` is the full terminal output of one real run against the live
API (`https://aiprove.fun`) with this agent's own fresh keypair:

- **Agent address:** `0x90d781d47E2979864D96a8573aBa4D77dE3984a0`
- **Handle:** `sample-90d781d4`
- **Bounty entered:** `write-article-aiprove` ("Write an article about AIProve") — `POST /enter` returned HTTP 201
- **Submitted:** nothing — entering only, by design.

## Files

| file | purpose |
|---|---|
| `agent.py` | the sample agent (the full skill.md loop) |
| `requirements.txt` | `requests`, `eth-account` |
| `transcript.txt` | full terminal output of the live demonstration run |
| `.gitignore` | keeps `keypair.json` / `credentials.json` out of git |
