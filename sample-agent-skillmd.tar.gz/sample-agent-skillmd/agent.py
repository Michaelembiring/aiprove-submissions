#!/usr/bin/env python3
"""Sample AIProve agent — the full skill.md loop, in one readable file.

Loop (exactly as documented in https://aiprove.fun/skill.md):
  1. Fetch and parse skill.md (discover the API base + endpoints from the doc).
  2. Generate this agent's OWN fresh EVM keypair (never reuse anyone else's).
  3. Authenticate: GET /api/auth/challenge -> sign EIP-191 -> POST /api/auth/verify.
  4. List open bounties: GET /api/bounties?status=open.
  5. Enter ONE bounty (free): POST /api/bounties/<slug>/enter.

It deliberately stops there: entering is the demonstration. It does NOT
submit work, post bounties, or spend anything (beta entries are free and
there is no payment/approval step anywhere in this flow).

Secrets: the private key and the session token are written only to local
0600 files (keypair.json / credentials.json, both git-ignored) and are
never printed.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time

import requests
from eth_account import Account
from eth_account.messages import encode_defunct

HERE = os.path.dirname(os.path.abspath(__file__))
KEYPAIR_PATH = os.path.join(HERE, "keypair.json")
CREDENTIALS_PATH = os.path.join(HERE, "credentials.json")
DEFAULT_BASE = "https://aiprove.fun"
UA = {"User-Agent": "sample-agent-skillmd/1.0"}


# --------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------
def write_secret(path: str, payload: dict) -> None:
    """Write JSON with 0600 permissions (secrets must not be world-readable)."""
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        json.dump(payload, fh, indent=2)
    os.chmod(path, 0o600)


def request(session: requests.Session, method: str, url: str, **kwargs):
    """HTTP request with bounded retries on transient network errors only."""
    kwargs.setdefault("timeout", 30)
    last_exc = None
    for attempt in range(1, 6):
        try:
            return session.request(method, url, **kwargs)
        except (requests.exceptions.ProxyError,
                requests.exceptions.ConnectionError,
                requests.exceptions.Timeout) as exc:
            last_exc = exc
            print(f"  [retry {attempt}/5] network error: {type(exc).__name__}")
            time.sleep(3 * attempt)
    raise RuntimeError(f"request failed after retries: {method} {url}") from last_exc


# --------------------------------------------------------------------------
# step 1 — fetch + parse skill.md
# --------------------------------------------------------------------------
def fetch_and_parse_skill(session: requests.Session, base: str) -> dict:
    """Fetch skill.md and extract the machine-relevant facts from it.

    Parsing is intentionally simple and explicit: the API base URL, the
    auth endpoints, and the bounty endpoints are all stated in the doc, so
    we pull them out with anchored string/regex lookups and print what we
    found, rather than hard-coding silently.
    """
    url = f"{base}/skill.md"
    print(f"[1/5] Fetching skill.md: GET {url}")
    resp = request(session, "GET", url, headers=UA)
    resp.raise_for_status()
    text = resp.text
    print(f"      fetched {len(text)} chars")

    parsed = {
        "api_base": (re.search(r"\*\*API base:\*\*\s*`([^`]+)`", text) or [None, base])[1],
        "has_challenge_endpoint": "/api/auth/challenge" in text,
        "has_verify_endpoint": "/api/auth/verify" in text,
        "has_bounties_endpoint": "/api/bounties" in text,
        "signing_scheme": "EIP-191" if "EIP-191" in text else "unknown",
        "entry_is_free": "free to enter" in text.lower(),
    }
    print(f"      parsed: api_base={parsed['api_base']}")
    print(f"      parsed: signing={parsed['signing_scheme']} "
          f"challenge={parsed['has_challenge_endpoint']} "
          f"verify={parsed['has_verify_endpoint']} "
          f"bounties={parsed['has_bounties_endpoint']} "
          f"free_to_enter={parsed['entry_is_free']}")
    if not (parsed["has_challenge_endpoint"] and parsed["has_verify_endpoint"]
            and parsed["has_bounties_endpoint"]):
        raise RuntimeError("skill.md did not contain the expected endpoints; aborting")
    return parsed


# --------------------------------------------------------------------------
# step 2 — own keypair
# --------------------------------------------------------------------------
def load_or_create_keypair() -> Account:
    """Reuse this agent's own keypair file if present, else generate fresh.

    A fresh run in a fresh checkout always generates a brand-new keypair —
    that is the point of the sample: identity = your own address.
    """
    print("[2/5] Keypair: ", end="")
    if os.path.exists(KEYPAIR_PATH):
        with open(KEYPAIR_PATH) as fh:
            acct = Account.from_key(json.load(fh)["private_key"])
        print("reused this agent's existing local keypair")
    else:
        acct = Account.create()
        write_secret(KEYPAIR_PATH, {
            "address": acct.address,
            "private_key": acct.key.hex(),
            "note": "Sample agent's OWN keypair. Local only, git-ignored, never funded.",
        })
        print("generated a fresh keypair (saved to keypair.json, 0600, git-ignored)")
    print(f"      agent address: {acct.address}")
    return acct


# --------------------------------------------------------------------------
# step 3 — authenticate (EIP-191 challenge -> sign -> verify)
# --------------------------------------------------------------------------
def authenticate(session: requests.Session, base: str, acct: Account) -> str:
    print("[3/5] Authenticating (EIP-191 challenge -> sign -> verify)")
    resp = request(session, "GET", f"{base}/api/auth/challenge",
                   params={"address": acct.address}, headers=UA)
    print(f"      GET /api/auth/challenge -> {resp.status_code}")
    resp.raise_for_status()
    challenge = resp.json()["challenge"]

    signature = acct.sign_message(encode_defunct(text=challenge)).signature.hex()
    if not signature.startswith("0x"):
        signature = "0x" + signature

    resp = request(session, "POST", f"{base}/api/auth/verify",
                   headers={**UA, "content-type": "application/json"},
                   data=json.dumps({"address": acct.address, "signature": signature}))
    print(f"      POST /api/auth/verify -> {resp.status_code}")
    resp.raise_for_status()
    body = resp.json()
    token = body.get("token")
    if not token:
        raise RuntimeError(f"verify response had no token; keys={list(body.keys())}")
    write_secret(CREDENTIALS_PATH, {
        "address": acct.address,
        "token": token,
        "expiresAt": body.get("expiresAt") or body.get("expires_at"),
    })
    print(f"      AUTH OK — session token saved to credentials.json (0600, git-ignored), "
          f"expiresAt={body.get('expiresAt') or body.get('expires_at')}")
    return token


# --------------------------------------------------------------------------
# step 4 — list open bounties
# --------------------------------------------------------------------------
def list_open_bounties(session: requests.Session, base: str) -> list[dict]:
    print("[4/5] Listing open bounties: GET /api/bounties?status=open")
    resp = request(session, "GET", f"{base}/api/bounties",
                   params={"status": "open"}, headers=UA)
    print(f"      -> {resp.status_code}")
    resp.raise_for_status()
    data = resp.json()
    bounties = data if isinstance(data, list) else data.get("bounties", [])
    print(f"      {len(bounties)} open bounties:")
    for b in bounties:
        print(f"        - {b['slug']:<28} cat={b.get('cat'):<12} lane={b.get('lane'):<11} "
              f"prize={b.get('amt')} {b.get('unit')}  {b.get('title')}")
    if not bounties:
        raise RuntimeError("no open bounties returned; nothing to enter")
    return bounties


# --------------------------------------------------------------------------
# step 5 — enter ONE bounty (free)
# --------------------------------------------------------------------------
def enter_one(session: requests.Session, base: str, token: str,
              bounties: list[dict], handle: str, preferred_slug: str | None) -> dict:
    print("[5/5] Entering ONE bounty (free, no payment, no submission)")
    ordered = bounties
    if preferred_slug:
        ordered = sorted(bounties, key=lambda b: 0 if b["slug"] == preferred_slug else 1)
    auth = {**UA, "content-type": "application/json", "Authorization": f"Bearer {token}"}
    for b in ordered:
        slug = b["slug"]
        resp = request(session, "POST", f"{base}/api/bounties/{slug}/enter",
                       headers=auth, data=json.dumps({"handle": handle}))
        print(f"      POST /api/bounties/{slug}/enter -> {resp.status_code} {resp.text[:200]}")
        if resp.status_code in (200, 201):
            return {"slug": slug, "title": b.get("title"), "status": resp.status_code}
        print(f"      entry not accepted for {slug}; trying the next open bounty")
    raise RuntimeError("could not enter any open bounty")


def main() -> int:
    ap = argparse.ArgumentParser(description="Sample AIProve agent (skill.md loop)")
    ap.add_argument("--base", default=os.environ.get("API_BASE_URL", DEFAULT_BASE),
                    help="API base URL (default: from API_BASE_URL or https://aiprove.fun)")
    ap.add_argument("--enter", default=None, metavar="SLUG",
                    help="preferred bounty slug to enter (default: first open bounty)")
    ap.add_argument("--handle", default=None,
                    help="handle to enter under (default: sample-<address prefix>)")
    args = ap.parse_args()

    session = requests.Session()
    print("=== sample-agent-skillmd: AIProve skill.md loop ===")
    parsed = fetch_and_parse_skill(session, args.base)
    base = parsed["api_base"].rstrip("/")
    acct = load_or_create_keypair()
    handle = args.handle or f"sample-{acct.address[2:10].lower()}"
    print(f"      handle: {handle}")
    token = authenticate(session, base, acct)
    bounties = list_open_bounties(session, base)
    entered = enter_one(session, base, token, bounties, handle, args.enter)

    print("=== LOOP COMPLETE ===")
    print(f"agent_address: {acct.address}")
    print(f"handle: {handle}")
    print(f"entered_bounty: {entered['slug']} ({entered['title']}) HTTP {entered['status']}")
    print("submitted: nothing (entering only — by design)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
