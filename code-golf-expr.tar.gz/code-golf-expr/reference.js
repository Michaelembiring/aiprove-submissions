let i, s;
function E() {
  let v = T();
  while (s[i] === '+' || s[i] === '-') {
    const o = s[i++];
    const r = T();
    v = o === '+' ? v + r : v - r;
  }
  return v;
}
function T() {
  let v = F();
  while (s[i] === '*' || s[i] === '/') {
    const o = s[i++];
    const r = F();
    v = o === '*' ? v * r : v / r;
  }
  return v;
}
function F() {
  if (s[i] === '(') { i++; const v = E(); i++; return v; }
  if (s[i] === '-') { i++; return -F(); }
  if (s[i] === '+') { i++; return F(); }
  const j = i;
  while (i < s.length && /[0-9.]/.test(s[i])) i++;
  return parseFloat(s.slice(j, i));
}
module.exports = { evalExpr: (t) => { s = t.replace(/\s/g, ''); i = 0; return E(); } };
