// Tests for index.js (the golfed entry).
// Runs every public case from cases.json plus extra hidden-style cases:
// unary +/-, whitespace, leading zeros, ".5" / "5." literals, left
// associativity of - and /, nested parentheses, signed zero division.
const fs = require('fs');
const { evalExpr } = require('./index.js');
const pub = JSON.parse(fs.readFileSync('./cases.json', 'utf8'));
const extra = [
  ["-3+5", 2], ["2*-3", -6], ["-(2+3)", -5], ["+7", 7], ["--5", 5],
  [" 1 + 2 * 3 ", 7], [".5*2", 1], ["5.", 5], ["007+1", 8], ["010", 10],
  ["100/10/2", 5], ["8/2*2", 8], ["1-2-3-4", -8], ["2*(3+4)/7", 2],
  ["0.1+0.2", 0.30000000000000004], ["1/3", 1 / 3], ["(((((9)))))", 9],
  ["3*-(-2)", 6], ["10-2*3+1", 5], ["1.5*4/2", 3], ["42", 42],
  ["9/(3/3)", 9], ["2+3*4-6/2", 11], ["-2*-2*-2", -8], ["((((1+2))))*(((3)))", 9],
  ["6/(1-0.5)", 12], ["0", 0], ["0.5", 0.5], ["12/5", 2.4],
];
let fails = 0, total = 0;
for (const [cases, label] of [[pub.map(c => [c.in, c.out]), 'public'], [extra, 'extra']]) {
  for (const [inp, exp] of cases) {
    total++;
    let got, ok;
    try { got = evalExpr(inp); ok = Math.abs(got - exp) < 1e-12; }
    catch (e) { got = 'THREW: ' + e.message; ok = false; }
    console.log(`${ok ? 'PASS' : 'FAIL'} [${label}] evalExpr(${JSON.stringify(inp)}) = ${got}` + (ok ? '' : `, expected ${exp}`));
    if (!ok) fails++;
  }
}
console.log(`\n${total - fails}/${total} cases passed (${pub.length} public + ${extra.length} extra)`);
console.log(`index.js size: ${fs.statSync('./index.js').size} bytes`);
process.exit(fails ? 1 : 0);
