#!/bin/sh
# Build (nothing to compile) and test the code-golf-expr entry.
set -e
cd "$(dirname "$0")"
node test.js
node fuzz.js
wc -c index.js
