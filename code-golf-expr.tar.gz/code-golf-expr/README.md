# code-golf-expr

Implements `evalExpr(s)` for a tiny arithmetic language: `+ - * /`,
integer and decimal literals, parentheses, and normal precedence.
Returns a number.

## Entry

- File: **`index.js`** — a single file exporting the function exactly as
  the spec requires: `module.exports = { evalExpr }`.
- Size: **286 bytes** (including the trailing newline).
- Usage: `const { evalExpr } = require('./index.js'); evalExpr('1+2*3') // 7`

## How it works

A real parser, golfed — no `eval` of the input:

1. **Tokenizer** — one regex pass, `s.match(/[\d.]+|\S/g)`, splits the
   string into number tokens and single-character operator/paren tokens,
   and drops whitespace for free.
2. **Precedence climbing** — `P(m)` parses binary operators with
   precedence ≥ `m` (`*` `/` = 2, `+` `-` = 1), recursing with `m = p+1`
   so same-precedence operators stay left-associative.
3. **Factors** — `F()` handles parenthesised sub-expressions, unary
   `-`/`+` (including chains like `--5` and `2*-3`), and number literals
   (`007`, `.5`, `5.` all parse as decimal, never octal).

Correctness was put before size: an earlier draft applied operators via
`eval(v + o + '(' + r + ')')` to save bytes, and differential fuzzing
caught it turning `x / -0` into `+Infinity` (stringifying `-0` loses the
sign). It was replaced with explicit operator application.

## Tests

`./build_and_test.sh` runs:

- `node test.js` — all **9/9 public cases** from `cases.json`, plus 29
  extra hidden-style cases (unary signs, whitespace, leading zeros,
  `.5`/`5.` literals, left-associativity of `-` and `/`, deep nesting,
  signed-zero division): **38/38 passed**.
- `node fuzz.js` — 5,000 random expressions compared against the clear
  reference parser in `reference.js`: **5,000/5,000 agree**.

Full build + test output is in `transcript.txt`. (`test.js`, `fuzz.js`
and `reference.js` are test scaffolding only; the scored entry is
`index.js` alone.)
