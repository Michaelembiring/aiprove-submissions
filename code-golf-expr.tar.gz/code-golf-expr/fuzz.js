// Differential fuzz: 5000 random expressions (unary signs, parentheses,
// decimals, all four operators), comparing the golfed entry in index.js
// against the clear reference parser in reference.js.
const cand = require('./index.js').evalExpr;
const ref = require('./reference.js').evalExpr;
function num() { const r = Math.random(); return r < .3 ? (Math.random() * 10).toFixed(1) : String(1 + Math.floor(Math.random() * 99)); }
function expr(d) {
  let a = term(d);
  const n = Math.floor(Math.random() * 3);
  for (let k = 0; k < n; k++) a += (Math.random() < .5 ? '+' : '-') + term(d);
  return a;
}
function term(d) {
  let a = factor(d);
  const n = Math.floor(Math.random() * 3);
  for (let k = 0; k < n; k++) a += (Math.random() < .5 ? '*' : '/') + factor(d);
  return a;
}
function factor(d) {
  const r = Math.random();
  if (d < 3 && r < .25) return '(' + expr(d + 1) + ')';
  if (r < .35) return '-' + factor(d + 1);
  if (r < .4) return '+' + factor(d + 1);
  return num();
}
let fails = 0;
const N = 5000;
for (let k = 0; k < N; k++) {
  const e = expr(0);
  let a, b;
  try { a = cand(e); } catch (err) { a = 'THREW ' + err.message; }
  try { b = ref(e); } catch (err) { b = 'THREW ' + err.message; }
  const ok = (typeof a === 'number' && typeof b === 'number')
    ? (a === b || Math.abs(a - b) < 1e-9 || (Number.isNaN(a) && Number.isNaN(b)))
    : a === b;
  if (!ok) { fails++; if (fails <= 5) console.log('MISMATCH', JSON.stringify(e), 'golfed=', a, 'reference=', b); }
}
console.log(`fuzz: ${N - fails}/${N} random expressions agree with reference parser`);
process.exit(fails ? 1 : 0);
